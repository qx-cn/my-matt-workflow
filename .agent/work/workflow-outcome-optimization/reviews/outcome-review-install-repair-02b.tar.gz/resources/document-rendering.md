# 文档内容与前端交接

带前端渲染的文档型 Skill 使用同一入口的三个阶段：

- `content`：内容模型读取事实来源并产出语义工件；不得写 HTML、CSS 或 JavaScript。宿主 Skill 未另行定义普通调用行为时，没有显式阶段且不存在可用语义工件才默认执行此阶段并在交接点停止。
- `frontend <artifact>`：前端模型只消费语义工件、模板和渲染资产；负责布局、样式、交互、响应式与视觉验收，不重新解释源材料，不增删或改写事实、结论和约束。
- `full`：显式要求同一运行连续完成两个阶段时，仍先落盘并校验语义工件，再渲染。此模式不提供模型隔离证据；该说明属于 Agent 对话中的交付状态，不进入面向读者的成品。

语义工件是 Markdown，frontmatter 至少包含：

```yaml
---
document_kind: <stable-kind>
content_revision: 1
status: content-ready
reader: <primary reader>
purpose: <decision or action>
output_path: <rendered file path>
template_ref: <template or asset reference>
source_refs: [<authoritative inputs>]
---
```

语义工件正文必须提供：结论、证据与未知、按顺序排列的章节（每节包含稳定 `section_id`）、事实/结论清单、必要关系，以及逐节判定的 `visual_intent`。这些字段用于核验与交接，不是要求前端照抄的成品标题。

`content_revision`、status、来源账本、模型隔离声明、事实/结论清单、必要关系和作者研究缺口只留在语义工件。前端只把读者需要的事实、因果、限制、反例，以及宿主要求的练习和答案写入成品；若内部关系清单对复习有用，应改成自然的读者标题。作者研究缺口不得渲染，影响读者判断的未知则由内容阶段另写成正文限制或下一步核验。教学课页中的来源只做页脚引用或文内归属，不渲染为制作看板。

`visual_intent` 只描述要回答的一个问题和数据关系，不指定像素、配色或具体前端实现。按[读者表达判断](visual-communication.md)选择形式，文字足够时可写 `none` 并给理由；内容类别不自动要求图示。

内容阶段完成时报告语义工件绝对路径和下一条同入口调用，例如 `/<skill> frontend <artifact>`，然后停止。这是允许用户或宿主切换模型的真实交接点，不假设输出一行命令会自动触发下一阶段。

前端阶段先检查必填字段、来源引用、章节顺序和未知项。承重内容缺失时返回 `blocked-by-content`，指出 `section_id` 并停止；不能仅因结构、流程或状态内容选择 `none` 而阻断；只有必要关系缺失或含混导致无法准确呈现才阻断。前端不得自行补写，并须实现所有非 `none` 意图。完成后逐项核对读者可见的事实、因果、限制、反例及宿主要求的练习、答案和来源归属；不要求内部字段或作者研究缺口出现在成品。输出路径、模型隔离与视觉验收范围只在 Agent 对话中报告。
