# Ticket 准入、完成与选择适配

本适配描述 Ticket 准入、完成与选择的本地约定。本地 Ticket 使用 YAML frontmatter：`ticket_kind` 只能是 `implementation` 或 `wayfinder-decision`；`status`、`blocked_by`（YAML 列表）和 `claimed_by` 必须显式存在。`claimed_by:` 的显式空标量表示未认领；缺失、列表或映射都无效，绝不把它们推断为未认领。缺失或旧式 `ticket_kind` 同样是歧义，绝不推断。

实施候选必须同时是 `ticket_kind: implementation`、`status: ready-for-agent | revalidated`、未认领、每个 `blocked_by` Ticket 的 `status: complete`，并至少有一个未勾选的验收复选框。它还必须声明 `execution_agent: auto | codex | cursor | claude`、`spec_id`、正整数 `spec_revision`、可定位的 `spec_ref`；旧版可选 rule_* 字段继续读取，未解决 rule_conflicts 阻止开工，新 Ticket 无需这些字段，触点提示非约束性；可选 `review_probes` 只能声明 `recovery` 与 `unknown-response`，由 Spec 的持久化恢复或未知外部响应风险决定。实施前运行 `workflow.py validate-ticket <ticket-path>` 验证。`wayfinder-decision` 或任何 `wayfinder:*` 标签永远不得进入实施，即使其他字段看似就绪。引用只可按唯一的 id、路径或标题解析；孤儿、歧义和依赖环必须先修复。

自动选择只从合格候选中按 `sequence`、再按稳定 id 排序。用户明确选择的 Ticket 不合格时，报告全部缺项并停止；不得静默重选。Triage 不重新处理已有结构化 implementation Ticket；Wayfinder Ticket 也不转换为 implementation。

Wayfinder frontier 只包括 `ticket_kind: wayfinder-decision`、`status: open`、显式未认领且所有 `blocked_by` Ticket 已 `complete` 的 Ticket；其选择规则与 implementation 完全独立。读取 frontier 时按稳定排序（`sequence` 升序、再按 id 字典序）输出；用户明确指定不合格 Ticket 时报告全部缺项并停止，不得静默回退或重选。

implementation Ticket 的主路径为 `ready-for-agent → implementing → complete`，由 `implement` 命令校验。审查停止进入 `needs-user`，由 `resolve` 接受或重开；批次收口前 complete 表示已提交、待批次收口，审查修复留本批次；批次收口后已完成记录不改写，后续改变用补偿或迁移 Ticket。可选整分支审查的修复由最后批次承接，是唯一例外。

关闭 implementation Ticket 前，所有验收复选框必须勾选；否则保留开放状态并说明未完成项。用户专属产品取舍不由这个机械门槛代替。
