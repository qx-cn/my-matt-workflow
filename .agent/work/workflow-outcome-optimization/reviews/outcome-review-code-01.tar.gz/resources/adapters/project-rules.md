# 项目规则解析适配

规则的权力边界与冲突处理遵循[指令权威](../instruction-authority.md)。

`default_execution_agent` 只为未显式分配的 Ticket 提供 `execution_agent` 初值。只有 Ticket 的 `execution_agent` 选择执行 Agent：`auto` 在 `implement start` 绑定当前 Agent，实施记录固定本次执行结果；后续实施和审查只使用该值。规划可用当前安装状态的 `installed_agent` 收集初步规则证据，但这不分配执行 Agent，也不能代替每张 Ticket 在实施前的规则解析；明确指定的 Agent 与当前环境不一致时停止，不得混读多个 Agent 的专属规则。

共享标准来自贡献规范、编码规范与相关 ADR。跨 Agent 约束若维护在 `AGENTS.md`，非 Codex Agent 只能把它作为 workflow 约定读取；这不改变各宿主自身的原生规则发现方式。

先从当前 Agent 的 `my-matt-workflow/install-state.json` 读取绝对路径 `runtime_entry`：Codex 状态根为 `${CODEX_HOME:-~/.codex}`，Cursor 为 `~/.cursor`，Claude 为 `~/.claude`；自定义安装则使用安装时指定的 Agent 根目录。使用 `python3 <runtime_entry> resolve-rules --repo <repo> --agent <codex|cursor|claude> --path <影响路径>` 获取规则证据。不得假设当前项目中存在本工作流仓库的 `tools/`。解析器只读取该目标 Agent 的来源：

- `codex`：贡献/编码标准，以及从仓库根到每个影响路径父目录的原生 `AGENTS*` 指令；每层只选择首个非空的 `AGENTS.override.md`、`AGENTS.md` 或已配置 fallback，越靠近影响路径的规则 `precedence_index` 越大；自定义 fallback 以 `--codex-fallback <文件名>` 传入；
- `cursor`：`AGENTS.md` 跨 Agent 约定、贡献/编码标准、`.cursorrules`、`.cursor/rules/**/*.mdc`；
- `claude`：`AGENTS.md` 跨 Agent 约定、贡献/编码标准、`CLAUDE.md`、`.claude/CLAUDE.md`、`.claude/rules/**/*.md`。

`.agent/rules/**/*` 不是 Codex 原生项目指令，不得把它冒充 `AGENTS.md` 证据。个人全局 `~/.codex/AGENTS*` 只属于当前运行环境，不写入可共享 Ticket。

Cursor 规则必须按原生语义处理：`alwaysApply: true` 全局适用；`globs` 只匹配目标路径；只有 `description` 的规则需要相关性判断；无三者的规则仅在显式手动引用时适用。Claude 的 `paths` 规则也只在匹配路径时适用。

`resolve-rules` 只返回实施时可选择或需要语义判断的规则，不是完整 inventory 或 metadata validator。审查项目规则时使用 `python3 <runtime_entry> inspect-rules --repo <repo> --agent <codex|cursor|claude> [--path <路径> ...]`：它保留 manual、shadowed、candidate 与 invalid 规则，并以 `target_match: null` 表示仍需语义判断或显式引用。invalid metadata 不能退化为 always，也不能因为未出现在 `resolve-rules` 中而被当作不存在。

## 计划输出

Spec 不声明执行 Agent；输出前只解析跨 Agent 的项目规则与 ADR。Ticket 先确定自己的 `execution_agent`，再解析目标 Agent 的规则。计划顶部只记录 Ticket 级执行选择与未解决冲突数；不要写冗长规则综述。每个计划项固定写四项：

- **影响区域**：模块、目录或 glob；
- **规则**：来源及匹配依据；
- **约束**：由规则推出的可执行设计或测试要求；
- **验证**：证明该项满足约束的测试、检查或人工验证。

计划中的规则证据供切分参考，不强制写入 Ticket frontmatter；新 Ticket 不要求 rule_sources/rule_scope/rule_constraints/rule_conflicts。旧字段兼容读取，未解决冲突仍阻止开工。runtime 开工按实际路径解析；无路径声明时保守覆盖现有仓库文件，审查按实际改动路径重新核对。触点提示只是非约束性上下文。

## 实施与审查

开始每个 Ticket 前，按真实将修改的路径和 run context 固定的 Agent 重新执行 `resolve-rules`，再运行 `python3 <runtime_entry> validate-ticket <ticket-path>`。新规则若改变架构、接口、范围或验收，回到计划确认；审查发现必须引用规则来源与匹配依据。
