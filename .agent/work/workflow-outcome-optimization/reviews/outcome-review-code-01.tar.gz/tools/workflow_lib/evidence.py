"""Shared command observations and frozen-byte integrity, without scope policy."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys


def execution_observed(output):
    cases=re.findall(r'^(?:FAIL|ERROR): (.+)$',output,re.M)
    loader_errors=sum('unittest.loader._FailedTest.' in case for case in cases)
    if any('unittest.loader._FailedTest.' not in case for case in cases):return True
    ran=re.search(r'^Ran (\d+) tests?\b',output,re.M)
    if ran and int(ran.group(1))>loader_errors:return True
    return bool(re.search(r'^FAILED\s+[^\s(]\S*|^\s*--- FAIL: |\b[1-9]\d* passed\b',output,re.M))


def environment(repo,argv):
    return dict(python=sys.version,python_executable=sys.executable,platform=platform.platform(),
                executable=shutil.which(argv[0]) if '/' not in argv[0] else str((repo/argv[0]).resolve()))


def execute(repo, argv):
    """Return raw facts; each caller retains its own success/comparison policy."""
    from . import topic_service as topics
    identity=topics.content_id(repo)
    execution_environment=environment(repo,argv)
    try:
        result=subprocess.run(argv,cwd=repo,capture_output=True,text=True,errors='replace')
        code,output=result.returncode,result.stdout+result.stderr
        unavailable=code!=0 and (code in (126,127) or bool(re.search(r'ModuleNotFoundError|No module named|command not found',output))) and not execution_observed(output)
    except OSError as exc:
        code,output,unavailable=127,str(exc),True
    return dict(argv=argv,exit_code=code,content_id=identity,environment=execution_environment,
                unavailable=unavailable,content_changed=topics.content_id(repo)!=identity,
                output_tail=output[-4000:]),output


def bytes_match(path, sha256, size=None):
    content=Path(path).read_bytes()
    return hashlib.sha256(content).hexdigest()==sha256 and (size is None or len(content)==size)


def frozen_manifest(active):
    from .topic_service import TopicError
    path=Path(active['manifest'])
    if not bytes_match(path,active['manifest_sha256']):
        raise TopicError('manifest: 冻结材料已变化，请重新 review')
    manifest=json.loads(path.read_text())
    entries=manifest['inputs']+[e for c in manifest['changes'] for e in (c['base'],c['current']) if e]
    if any(not bytes_match(e['snapshot_path'],e['sha256']) for e in entries):
        raise TopicError('snapshot: 冻结材料已变化，请重新 review')
    return manifest


def accepted_matches(path, entry):
    path=Path(path)
    return path.is_file() and json.loads(path.read_text())==entry
