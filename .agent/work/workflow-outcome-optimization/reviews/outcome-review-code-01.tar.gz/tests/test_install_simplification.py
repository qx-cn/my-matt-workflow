"""Public install/deploy regressions and byte-exact projection checks."""
import argparse
import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tools.workflow_lib import installer, release, projection

ROOT = Path(__file__).resolve().parents[1]


def fixture(root):
    skill = root / 'skills/my-demo'
    skill.mkdir(parents=True)
    (skill / 'SKILL.md').write_text('---\nname: my-demo\ndescription: test\ndisable-model-invocation: true\n---\n# Demo\n')
    return root


def cli(root):
    spec = importlib.util.spec_from_file_location('simplified_workflow_cli', ROOT / 'tools/workflow.py')
    module = importlib.util.module_from_spec(spec)
    with patch.object(sys, 'path', [str(ROOT / 'tools'), *sys.path]):
        spec.loader.exec_module(module)
    module.ROOT = root
    module.AGENT_STATE_HOMES = {}
    return module


class SimplifiedInstallTests(unittest.TestCase):
    def test_projection_manifest_matches_physical_bytes_without_copytree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            skill = root / 'skills/my-demo'
            (skill / 'agents').mkdir()
            (skill / 'agents/openai.yaml').write_text('metadata')
            (skill / 'nested').mkdir()
            (skill / 'nested/demo.md').write_bytes(b'{{skill-call:my-demo}}\r\n')
            for target in projection.TARGETS:
                with self.subTest(target=target):
                    staged = Path(tmp) / target
                    shutil.copytree(skill, staged)
                    projection.project_skill_directory(staged, target)
                    expected = projection.directory_inventory(staged)
                    with patch.object(shutil, 'copytree', side_effect=AssertionError('projection copied tree')):
                        self.assertEqual(expected, projection.projected_skill_inventory(skill, target))

    def test_changed_deploy_runs_one_gate_on_packaged_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            module = cli(root)
            roots = []
            def gate(**kwargs):
                roots.append(kwargs.get('root', module.ROOT))
                self.assertEqual((root / 'skills/my-demo/SKILL.md').read_bytes(),
                                 (roots[-1] / 'skills/my-demo/SKILL.md').read_bytes())
                return {'status': 'valid'}
            with patch.object(module, '_run_all_up_gate', side_effect=gate):
                module.command_deploy(argparse.Namespace(release_id='v1', upstream_id='local',
                                                        target='auto', agent_home=str(Path(tmp) / 'home')))
            self.assertEqual(1, len(roots))
            self.assertNotEqual(root, roots[0])

    def test_unchanged_deploy_neither_stages_source_nor_rewrites_host(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root,
                                            current_pointer=root / 'current.json')
            home = Path(tmp) / 'home'
            installer.install_release(package, home)
            state_path = home / 'my-matt-workflow/install-state.json'
            state = state_path.read_bytes()
            inode = (home / 'skills/my-demo/SKILL.md').stat().st_ino
            module = cli(root)
            def reject_packaging(*args, **kwargs):
                raise AssertionError('repacked unchanged source')
            with patch.object(module, '_run_all_up_gate', return_value={'status':'valid'}) as gate, \
                 patch.dict(module.release_matches_source.__globals__,
                            {'source_manifest': reject_packaging}):
                module.command_deploy(argparse.Namespace(release_id=None, upstream_id='local',
                                                        target='auto', agent_home=str(home)))
            self.assertEqual(1, gate.call_count)
            self.assertEqual(state, state_path.read_bytes())
            self.assertEqual(inode, (home / 'skills/my-demo/SKILL.md').stat().st_ino)

    def test_public_deploy_runs_actual_suite_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            counter = Path(tmp) / 'suite-counter'
            (root / 'tests').mkdir()
            (root / 'tests/test_gate.py').write_text(
                'import unittest\nfrom pathlib import Path\n'
                'class Gate(unittest.TestCase):\n'
                ' def test_runs(self):\n'
                f'  p = Path({str(counter)!r})\n'
                '  p.write_text(str(int(p.read_text()) + 1) if p.exists() else "1")\n')
            module = cli(root)
            module.command_deploy(argparse.Namespace(release_id='actual-suite', upstream_id='local',
                                                    target='auto', agent_home=str(Path(tmp) / 'home')))
            self.assertEqual('1', counter.read_text())
            installer.verify_release(root / 'releases/actual-suite')

    def test_failed_suite_does_not_publish_or_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            (root / 'tests').mkdir()
            (root / 'tests/test_gate.py').write_text(
                'import unittest\nclass Gate(unittest.TestCase):\n'
                ' def test_fails(self): self.fail("candidate is invalid")\n')
            module = cli(root)
            home = Path(tmp) / 'home'
            with self.assertRaises(SystemExit):
                module.command_deploy(argparse.Namespace(release_id='bad', upstream_id='local',
                                                        target='auto', agent_home=str(home)))
            self.assertFalse((root / 'current.json').exists())
            self.assertFalse((root / 'releases/bad').exists())
            self.assertFalse(home.exists())

    def test_context_reuses_same_bytes_and_revalidates_drift_and_other_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            first = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                          upstream_id='local', repo_root=root)
            second = release.build_release(root / 'skills', root / 'releases', release_id='v2',
                                           upstream_id='local', repo_root=root)
            context = installer.ReleaseValidationContext()
            with patch.object(installer, 'verify_release', wraps=installer.verify_release) as verify:
                context.verify(first)
                context.verify(first)
                context.verify(second)
                self.assertEqual(2, verify.call_count)
                (first / 'skills/my-demo/SKILL.md').write_text('tampered')
                with self.assertRaises(installer.InstallError):
                    context.verify(first)
                self.assertEqual(3, verify.call_count)

    def test_install_rechecks_cached_package_inside_lock(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            context = installer.ReleaseValidationContext()
            context.verify(package)
            from tools.workflow_lib import fs_safety
            original_lock = installer.exclusive_lock
            from contextlib import contextmanager
            @contextmanager
            def mutate_under_lock(directory, name):
                with original_lock(directory, name):
                    if name == installer.REFERENCE_LOCK:
                        (package / 'skills/my-demo/SKILL.md').write_text('mutated after outer validation')
                    yield
            home = Path(tmp) / 'home'
            with patch.object(installer, 'exclusive_lock', side_effect=mutate_under_lock):
                with self.assertRaises(installer.InstallError):
                    installer.install_release(package, home, validation_context=context)
            self.assertFalse((home / 'skills/my-demo').exists())
            self.assertFalse((home / 'my-matt-workflow/install-state.json').exists())

    def test_same_release_install_verifies_once_and_detects_host_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            home = Path(tmp) / 'home'
            installer.install_release(package, home)
            with patch.object(installer, 'verify_release', wraps=installer.verify_release) as verify:
                self.assertEqual('current', installer.install_release(package, home))
                self.assertEqual(1, verify.call_count)
            (home / 'skills/my-demo/SKILL.md').write_text('tampered')
            with self.assertRaises(installer.InstallError):
                installer.install_release(package, home)

    def test_doctor_validates_shared_release_once_and_reports_each_host(self):
        from tools.workflow_lib.doctor import diagnose_repository
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root,
                                            current_pointer=root / 'current.json')
            homes = {name: Path(tmp) / name for name in ('host-a', 'host-b')}
            for home in homes.values():
                installer.install_release(package, home)
            with patch.object(installer, 'verify_release', wraps=installer.verify_release) as verify:
                report = diagnose_repository(root, homes)
                self.assertEqual(1, verify.call_count)
            self.assertEqual(True, report['current_release']['source_match'])
            self.assertEqual({'valid'}, {host['status'] for host in report['hosts'].values()})
            (homes['host-b'] / 'skills/my-demo/SKILL.md').write_text('tampered')
            report = diagnose_repository(root, homes)
            self.assertEqual('valid', report['hosts']['host-a']['status'])
            self.assertEqual('invalid', report['hosts']['host-b']['status'])

    def test_digest_binds_tests_config_links_permissions_and_upstream(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            self.assertTrue(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='changed'))
            added = root / 'tests/test_new.py'
            added.parent.mkdir()
            added.write_text('test configuration')
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            added.unlink()
            self.assertTrue(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            config = root / 'build-config.json'
            config.write_text('{"setting": true}')
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            config.unlink()
            builder = root / 'tools/projection_override.py'
            builder.parent.mkdir()
            builder.write_text('PROTOCOL = 2')
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            builder.unlink()
            link = root / 'config-link'
            link.symlink_to('skills/my-demo/SKILL.md')
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))
            link.unlink()
            skill = root / 'skills/my-demo/SKILL.md'
            skill.chmod(0o700)
            self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))

    def test_legacy_digest_missing_uses_full_source_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            manifest_path = package / 'manifest.json'
            manifest = json.loads(manifest_path.read_text())
            del manifest['source_input_digest']
            manifest_path.write_text(json.dumps(manifest))
            with patch.object(release, 'source_manifest', wraps=release.source_manifest) as stage:
                self.assertTrue(release.release_matches_source(package, root / 'skills', upstream_id='local'))
                self.assertEqual(1, stage.call_count)

    def test_release_verification_computes_projection_without_copytree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            with patch.object(shutil, 'copytree', side_effect=AssertionError('verify copied projection')):
                installer.verify_release(package)
            link = package / 'skills/my-demo/link'
            link.symlink_to('SKILL.md')
            with self.assertRaises(installer.InstallError):
                installer.verify_release(package)

    def test_unbound_or_forged_digest_cannot_hide_stale_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            (root / 'skills/my-demo/SKILL.md').write_text(
                (root / 'skills/my-demo/SKILL.md').read_text() + 'New requirement\n')
            manifest_path = package / 'manifest.json'
            manifest = json.loads(manifest_path.read_text())
            manifest['source_input_digest'] = release.source_input_digest(root, upstream_id='local')
            manifest_path.write_text(json.dumps(manifest))
            with patch.object(release, 'source_manifest', wraps=release.source_manifest) as stage:
                self.assertFalse(release.release_matches_source(package, root / 'skills', upstream_id='local'))
                self.assertEqual(1, stage.call_count)

    def test_context_detects_drift_during_validation_and_does_not_share_mutable_claims(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = fixture(Path(tmp) / 'repo')
            package = release.build_release(root / 'skills', root / 'releases', release_id='v1',
                                            upstream_id='local', repo_root=root)
            context = installer.ReleaseValidationContext()
            returned = context.verify(package)
            returned['skills'].clear()
            self.assertEqual({'my-demo'}, set(context.verify(package)['skills']))
            verify = installer.verify_release
            def mutate_after_verify(path):
                result = verify(path)
                (path / 'skills/my-demo/SKILL.md').write_text('concurrent mutation')
                return result
            with patch.object(installer, 'verify_release', side_effect=mutate_after_verify):
                with self.assertRaisesRegex(installer.InstallError, '漂移'):
                    installer.ReleaseValidationContext().verify(package)


if __name__ == '__main__':
    unittest.main()
