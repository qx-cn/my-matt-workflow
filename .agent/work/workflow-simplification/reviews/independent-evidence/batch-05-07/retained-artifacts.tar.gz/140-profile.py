"""Project profile parsing and safe personal-directory ignores."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from .composition import COMPOSITION_POLICY_MEANINGS
from .rules import EXECUTION_AGENTS


class ProfileError(ValueError):
    """Raised when a project profile is unsupported or invalid."""


SUPPORTED_SCHEMA_VERSION = 1
TASK_BACKENDS = {"local", "external", "project-docs", "none"}
AGENT_DIRECTORY_MODES = {"private", "shared"}
POLICIES = {"confirm", "allow", "deny"}
COMPOSITION_POLICIES = {"manual", "automatic"}
WORK_SCOPE_POLICIES = {"single-ticket", "ready-frontier", "approved-plan"}
DECISION_POLICIES = {"ask", "autonomous", "halt"}
ASSURANCE_LEVELS = {"quick", "standard", "audited"}

PROFILE_FIELD_ORDER = (
    "schema_version",
    "assurance_level",
    "task_backend",
    "agent_directory_mode",
    "default_base_branch",
    "branch_policy",
    "commit_policy",
    "external_write_policy",
    "docs_writeback",
    "humanizer_policy",
    "composition_policy",
    "work_scope_policy",
    "decision_policy",
    "default_execution_agent",
    "max_repair_rounds",
    "test_commands",
    "review_commands",
    "standards_sources",
    "domain_sources",
)

BASE_DEFAULTS: dict[str, Any] = {
    "schema_version": 1,
    "assurance_level": "standard",
    "task_backend": "local",
    "agent_directory_mode": "private",
    "default_base_branch": "main",
    "default_execution_agent": "auto",
    "max_repair_rounds": 1,
    "test_commands": [],
    "review_commands": [],
    "standards_sources": [],
    "domain_sources": [],
}

POLICY_PRESETS: dict[str, dict[str, str]] = {
    "strict-control": {
        "composition_policy": "manual",
        "work_scope_policy": "single-ticket",
        "decision_policy": "ask",
        "branch_policy": "confirm",
        "commit_policy": "confirm",
        "external_write_policy": "confirm",
        "docs_writeback": "confirm",
        "humanizer_policy": "deny",
    },
    "light-control": {
        "composition_policy": "automatic",
        "work_scope_policy": "single-ticket",
        "decision_policy": "ask",
        "branch_policy": "confirm",
        "commit_policy": "confirm",
        "external_write_policy": "confirm",
        "docs_writeback": "confirm",
        "humanizer_policy": "confirm",
    },
    "review": {
        "composition_policy": "automatic",
        "work_scope_policy": "single-ticket",
        "decision_policy": "ask",
        "branch_policy": "confirm",
        "commit_policy": "allow",
        "external_write_policy": "confirm",
        "docs_writeback": "confirm",
        "humanizer_policy": "confirm",
    },
    "semi-auto": {
        "composition_policy": "automatic",
        "work_scope_policy": "ready-frontier",
        "decision_policy": "ask",
        "branch_policy": "confirm",
        "commit_policy": "allow",
        "external_write_policy": "confirm",
        "docs_writeback": "confirm",
        "humanizer_policy": "confirm",
    },
    "full-auto": {
        "composition_policy": "automatic",
        "work_scope_policy": "approved-plan",
        "decision_policy": "autonomous",
        "branch_policy": "allow",
        "commit_policy": "allow",
        "external_write_policy": "allow",
        "docs_writeback": "allow",
        "humanizer_policy": "allow",
        "max_repair_rounds": 5,
    },
}

POLICY_PRESET_ALIASES = {
    "supervised": "strict-control",
    "unattended": "full-auto",
}

POLICY_PRESET_LABELS = {
    "strict-control": "严格控制，默认",
    "light-control": "轻轻控制",
    "review": "我做审核",
    "semi-auto": "半自动化",
    "full-auto": "全自动化",
}

POLICY_VALUE_MEANINGS: dict[str, dict[str, str]] = {
    "assurance_level": {
        "quick": "仅限单会话低风险工作；需求摘要、针对性测试和同会话自审",
        "standard": "版本化 Spec；按复杂度使用 Ticket，并保留测试与审查证据",
        "audited": "完整 Spec/Ticket 血缘、journal、冻结快照、receipt 和恢复门禁",
    },
    "task_backend": {
        "local": "本地 `.agent/work/` 产物",
        "external": "外部 Tracker",
        "project-docs": "项目文档后端",
        "none": "不使用任务后端",
    },
    "agent_directory_mode": {
        "private": "`.agent/` 为无 remote 的嵌套 Git 工作区，主仓库不跟踪它",
        "shared": "`.agent/` 由主仓库跟踪和推送，不创建嵌套 Git",
    },
    "branch_policy": {
        "confirm": "分支写操作前确认",
        "allow": "允许自动分支写操作",
        "deny": "禁止分支写操作",
    },
    "commit_policy": {
        "confirm": "提交前确认",
        "allow": "验证通过后可自动提交",
        "deny": "禁止提交",
    },
    "external_write_policy": {
        "confirm": "对外写（push/PR 等）前确认",
        "allow": "允许自动对外写",
        "deny": "禁止对外写",
    },
    "docs_writeback": {
        "confirm": "写回团队文档前确认",
        "allow": "允许自动写回文档",
        "deny": "禁止写回文档",
    },
    "humanizer_policy": {
        "deny": "不主动调用 /my-humanizer",
        "confirm": "调用 /my-humanizer 并先确认再落笔",
        "allow": "叙述段可自动 /my-humanizer 落笔；契约段仍冻结",
    },
    "composition_policy": COMPOSITION_POLICY_MEANINGS,
    "work_scope_policy": {
        "single-ticket": "完成当前 Ticket 后停止",
        "ready-frontier": "完成后自动选择当前 feature 的下一个就绪 frontier Ticket",
        "approved-plan": "按启动时批准的 Ticket 快照完成同一计划的依赖链",
    },
    "decision_policy": {
        "ask": "承重决定请求用户确认；普通可逆细节继续",
        "autonomous": "承重决定在已批准范围内记录证据后继续",
        "halt": "遇到承重决定暂停；普通可逆细节继续",
    },
    "default_execution_agent": {
        "auto": "由安装状态或当前执行环境解析",
        "codex": "默认由 Codex 实施",
        "cursor": "默认由 Cursor 实施",
        "claude": "默认由 Claude 实施",
    },
    "max_repair_rounds": {
        1: "首次 review finding 后只允许一轮受审方案修复",
        5: "最多五轮受审方案修复",
    },
}

def _is_empty(value: Any) -> bool:
    return value is None or value == ""


def _coalesce(config: dict[str, Any], key: str, default: Any) -> Any:
    if key not in config or _is_empty(config.get(key)):
        return default
    return config[key]


def resolve_preset_name(name: str) -> str:
    """Map preset aliases to canonical five-tier names."""
    if name in POLICY_PRESET_ALIASES:
        return POLICY_PRESET_ALIASES[name]
    if name in POLICY_PRESETS:
        return name
    raise ProfileError(
        "未知预设："
        f"{name!r}；可选：{', '.join(POLICY_PRESETS)}"
        f"；兼容别名：{', '.join(sorted(POLICY_PRESET_ALIASES))}"
    )


def get_policy_preset(name: str) -> dict[str, str]:
    """Return a copy of a preset, resolving legacy aliases."""
    return dict(POLICY_PRESETS[resolve_preset_name(name)])


def preset_cli_choices() -> list[str]:
    """CLI accepts canonical names plus legacy aliases."""
    return sorted(set(POLICY_PRESETS) | set(POLICY_PRESET_ALIASES))


def effective_profile(config: dict[str, Any]) -> dict[str, Any]:
    """Fill missing/empty keys from strict-control and base defaults."""
    strict = POLICY_PRESETS["strict-control"]
    result: dict[str, Any] = dict(BASE_DEFAULTS)
    result.update(strict)
    for key, value in config.items():
        if _is_empty(value):
            continue
        result[key] = value
    return result


def format_policy_catalog() -> str:
    """Authoritative value catalog shared by docs, render comments, and tests."""
    lines = [
        "配置取值说明（与校验同源）：",
        "",
        "日常主路径：五档预设 strict-control / light-control / review / "
        "semi-auto / full-auto。",
        "兼容别名：supervised→strict-control，unattended→full-auto。",
        "正交细项（branch/commit/external_write/docs_writeback/humanizer/"
        "composition/work_scope/decision 等）可逐项覆盖，属高级用法；"
        "ready-frontier、halt、deny 等枚举仍合法但非日常主路径。",
        "",
    ]
    defaults = effective_profile({})
    for key in PROFILE_FIELD_ORDER:
        if key in {"schema_version", "default_base_branch", "default_execution_agent", "max_repair_rounds", "test_commands", "review_commands",
                   "standards_sources", "domain_sources"}:
            lines.append(f"- {key}: 默认 {defaults[key]!r}")
            continue
        meanings = POLICY_VALUE_MEANINGS.get(key, {})
        if key == "task_backend":
            allowed = sorted(TASK_BACKENDS)
        elif key == "agent_directory_mode":
            allowed = sorted(AGENT_DIRECTORY_MODES)
        elif key in {
            "branch_policy",
            "commit_policy",
            "external_write_policy",
            "docs_writeback",
            "humanizer_policy",
        }:
            allowed = sorted(POLICIES)
        elif key == "composition_policy":
            allowed = sorted(COMPOSITION_POLICIES)
        elif key == "work_scope_policy":
            allowed = sorted(WORK_SCOPE_POLICIES)
        elif key == "decision_policy":
            allowed = sorted(DECISION_POLICIES)
        elif key == "default_execution_agent":
            allowed = ["auto", *sorted(EXECUTION_AGENTS)]
        elif key == "assurance_level":
            allowed = ["quick", "standard", "audited"]
        else:
            allowed = []
        detail = "; ".join(
            f"{value}（{meanings[value]}）" if value in meanings else value
            for value in allowed
        )
        lines.append(
            f"- {key}: 合法值 {', '.join(allowed)}；默认 {defaults[key]!r}"
            + (f"。{detail}" if detail else "")
        )
    lines.append("")
    lines.append("五档预设字段：")
    for name, label in POLICY_PRESET_LABELS.items():
        fields = ", ".join(
            f"{key}={value}" for key, value in POLICY_PRESETS[name].items()
        )
        lines.append(f"- {name}（{label}）: {fields}")
    return "\n".join(lines) + "\n"


def _parse_value(raw: str) -> Any:
    value = raw.strip()
    if value.startswith("[") and value.endswith("]"):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            try:
                parsed = json.loads(value.replace("'", '"'))
            except json.JSONDecodeError as exc:
                raise ProfileError(f"无效列表：{value}") from exc
        if not isinstance(parsed, list):
            raise ProfileError(f"预期列表：{value}")
        return parsed
    if value.isdigit():
        return int(value)
    if value in {"true", "false"}:
        return value == "true"
    return value.strip("\"'")


def _validate(config: dict[str, Any]) -> None:
    unknown = sorted(set(config) - set(PROFILE_FIELD_ORDER))
    if unknown:
        raise ProfileError(f"未知配置字段：{', '.join(unknown)}")
    for field in (
        "task_backend",
        "agent_directory_mode",
        "default_base_branch",
        "branch_policy",
        "commit_policy",
        "external_write_policy",
        "docs_writeback",
        "humanizer_policy",
        "composition_policy",
        "work_scope_policy",
        "decision_policy",
        "default_execution_agent",
        "assurance_level",
    ):
        if field in config and not _is_empty(config[field]) and not isinstance(config[field], str):
            raise ProfileError(f"{field} 必须是字符串")
    rounds = _coalesce(config, "max_repair_rounds", BASE_DEFAULTS["max_repair_rounds"])
    if not isinstance(rounds, int) or isinstance(rounds, bool) or rounds < 1 or rounds > 5:
        raise ProfileError("max_repair_rounds 必须是 1 到 5 的整数")
    for field in ("test_commands", "review_commands", "standards_sources", "domain_sources"):
        if field not in config or _is_empty(config[field]):
            continue
        value = config[field]
        if not isinstance(value, list) or any(
            not isinstance(item, str) or not item.strip() for item in value
        ):
            raise ProfileError(f"{field} 必须是非空字符串列表")
    version = _coalesce(config, "schema_version", BASE_DEFAULTS["schema_version"])
    if not isinstance(version, int) or isinstance(version, bool) or version != SUPPORTED_SCHEMA_VERSION:
        raise ProfileError(
            f"不支持 schema_version={version!r}，当前仅支持 {SUPPORTED_SCHEMA_VERSION}"
        )
    backend = _coalesce(config, "task_backend", BASE_DEFAULTS["task_backend"])
    if backend not in TASK_BACKENDS:
        raise ProfileError(
            f"task_backend 必须是：{', '.join(sorted(TASK_BACKENDS))}"
        )
    agent_directory_mode = _coalesce(
        config, "agent_directory_mode", BASE_DEFAULTS["agent_directory_mode"]
    )
    if agent_directory_mode not in AGENT_DIRECTORY_MODES:
        raise ProfileError(
            "agent_directory_mode 必须是："
            f"{', '.join(sorted(AGENT_DIRECTORY_MODES))}"
        )
    composition = _coalesce(
        config, "composition_policy", POLICY_PRESETS["strict-control"]["composition_policy"]
    )
    if composition not in COMPOSITION_POLICIES:
        raise ProfileError(
            "composition_policy 必须是："
            f"{', '.join(sorted(COMPOSITION_POLICIES))}"
        )
    work_scope = _coalesce(
        config, "work_scope_policy", POLICY_PRESETS["strict-control"]["work_scope_policy"]
    )
    if work_scope not in WORK_SCOPE_POLICIES:
        raise ProfileError(
            "work_scope_policy 必须是："
            f"{', '.join(sorted(WORK_SCOPE_POLICIES))}"
        )
    decision = _coalesce(
        config, "decision_policy", POLICY_PRESETS["strict-control"]["decision_policy"]
    )
    if decision not in DECISION_POLICIES:
        raise ProfileError(
            "decision_policy 必须是："
            f"{', '.join(sorted(DECISION_POLICIES))}"
        )
    if rounds > 1 and decision != "autonomous":
        raise ProfileError("max_repair_rounds 大于 1 仅允许 full-auto 的 autonomous 决策策略")
    execution_agent = _coalesce(
        config, "default_execution_agent", BASE_DEFAULTS["default_execution_agent"]
    )
    if execution_agent != "auto" and execution_agent not in EXECUTION_AGENTS:
        raise ProfileError("default_execution_agent 必须是 auto、codex、cursor 或 claude")
    assurance_level = _coalesce(
        config, "assurance_level", BASE_DEFAULTS["assurance_level"]
    )
    if assurance_level not in ASSURANCE_LEVELS:
        raise ProfileError("assurance_level 必须是：audited、quick 或 standard")
    for field in (
        "branch_policy",
        "commit_policy",
        "external_write_policy",
        "docs_writeback",
        "humanizer_policy",
    ):
        if field in config and not _is_empty(config[field]) and config[field] not in POLICIES:
            raise ProfileError(f"{field} 必须是：{', '.join(sorted(POLICIES))}")


def parse_profile(text: str) -> tuple[dict[str, Any], str]:
    """Parse the supported YAML-frontmatter subset and trailing Markdown."""
    lines = text.splitlines()
    if not lines or lines[0] != "---":
        raise ProfileError("配置必须以 YAML Frontmatter 开始")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ProfileError("配置缺少 Frontmatter 结束标记") from exc

    config: dict[str, Any] = {}
    for line in lines[1:end]:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            raise ProfileError(f"无效配置行：{line}")
        key, raw = line.split(":", 1)
        key = key.strip()
        if key in config:
            raise ProfileError(f"重复配置字段：{key}")
        config[key] = _parse_value(raw)

    _validate(config)
    notes = "\n".join(lines[end + 1 :]).strip()
    return config, notes


def render_profile(config: dict[str, Any], notes: str = "") -> str:
    """Render a validated profile with every known key made explicit."""
    effective = effective_profile(config)
    _validate(effective)
    lines = [
        "---",
        "# 策略预设：",
    ]
    for name, label in POLICY_PRESET_LABELS.items():
        preset = POLICY_PRESETS[name]
        summary = (
            f"{preset['composition_policy']}/"
            f"{preset['work_scope_policy']}/"
            f"{preset['decision_policy']}，"
            f"humanizer={preset['humanizer_policy']}"
        )
        marker = "（默认）" if name == "strict-control" else ""
        lines.append(f"# {name}{marker}：{label}；{summary}。")
    lines.extend(
        [
            "# 兼容别名：supervised→strict-control，unattended→full-auto。",
            "# 可用 `workflow.py setup --preset <"
            "strict-control|light-control|review|semi-auto|full-auto"
            "> --apply` 切换。",
            "# 「继续 / 提交并继续」只在当前已生效策略下推进，不升档、"
            "不放宽 work_scope_policy。",
            "# 缺键或空值按 strict-control 生效。",
            "# 下列值是本项目当前实际生效的策略。",
        ]
    )
    for key in PROFILE_FIELD_ORDER:
        value = effective[key]
        if isinstance(value, list):
            rendered = json.dumps(value, ensure_ascii=False)
        elif isinstance(value, bool):
            rendered = str(value).lower()
        else:
            rendered = str(value)
        lines.append(f"{key}: {rendered}")
    for key, value in effective.items():
        if key in PROFILE_FIELD_ORDER:
            continue
        if isinstance(value, list):
            rendered = json.dumps(value, ensure_ascii=False)
        elif isinstance(value, bool):
            rendered = str(value).lower()
        else:
            rendered = str(value)
        lines.append(f"{key}: {rendered}")
    lines.append("---")
    if notes.strip():
        lines.extend(("", notes.strip()))
    return "\n".join(lines) + "\n"


def merge_profile(
    existing: dict[str, Any],
    overrides: dict[str, Any],
) -> dict[str, Any]:
    """Merge confirmed refresh values without erasing prior configuration."""
    merged = dict(existing)
    merged.update({key: value for key, value in overrides.items() if value is not None})
    _validate(merged)
    return merged


def is_git_repository(repo: Path) -> bool:
    """Return whether the project is backed by a Git work tree."""
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and result.stdout.strip() == "true"


def apply_personal_ignores(repo: Path) -> tuple[list[str], list[str]]:
    """Compatibility shim: workflow setup never edits the parent `.gitignore`."""
    del repo
    return [], []
